/*
 Navicat Premium Dump SQL

 Source Server         : localhost
 Source Server Type    : MySQL
 Source Server Version : 80042 (8.0.42)
 Source Host           : localhost:3306
 Source Schema         : studentinfodb

 Target Server Type    : MySQL
 Target Server Version : 80042 (8.0.42)
 File Encoding         : 65001

 Date: 28/10/2025 21:29:26
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for 学生
-- ----------------------------
DROP TABLE IF EXISTS `学生`;
CREATE TABLE `学生`  (
  `学号` char(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `年龄` int NOT NULL,
  `性别` char(2) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `系号` char(4) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`学号`) USING BTREE,
  CONSTRAINT `学生_chk_1` CHECK (`年龄` between 16 and 30),
  CONSTRAINT `学生_chk_2` CHECK (`性别` in (_utf8mb4'男',_utf8mb4'女'))
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of 学生
-- ----------------------------
INSERT INTO `学生` VALUES ('S2024001', 20, '男', 'CS01');
INSERT INTO `学生` VALUES ('S2024002', 19, '女', 'MA01');
INSERT INTO `学生` VALUES ('S2024003', 22, '男', 'PH02');

-- ----------------------------
-- Table structure for 课程
-- ----------------------------
DROP TABLE IF EXISTS `课程`;
CREATE TABLE `课程`  (
  `课号` char(6) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `课名` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `学分` int NOT NULL,
  `学时` int NOT NULL,
  PRIMARY KEY (`课号`) USING BTREE,
  CONSTRAINT `课程_chk_1` CHECK (`学分` between 1 and 6),
  CONSTRAINT `课程_chk_2` CHECK (`学时` >= 16)
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of 课程
-- ----------------------------
INSERT INTO `课程` VALUES ('C00001', '数据库系统', 4, 64);
INSERT INTO `课程` VALUES ('C00002', '线性代数', 3, 48);
INSERT INTO `课程` VALUES ('C00003', '大学物理', 5, 80);

-- ----------------------------
-- Table structure for 选课
-- ----------------------------
DROP TABLE IF EXISTS `选课`;
CREATE TABLE `选课`  (
  `学号` char(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `课号` char(6) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `成绩` decimal(5, 1) NULL DEFAULT NULL,
  PRIMARY KEY (`学号`, `课号`) USING BTREE,
  INDEX `课号`(`课号` ASC) USING BTREE,
  CONSTRAINT `选课_ibfk_1` FOREIGN KEY (`学号`) REFERENCES `学生` (`学号`) ON DELETE CASCADE ON UPDATE RESTRICT,
  CONSTRAINT `选课_ibfk_2` FOREIGN KEY (`课号`) REFERENCES `课程` (`课号`) ON DELETE CASCADE ON UPDATE RESTRICT,
  CONSTRAINT `选课_chk_1` CHECK (`成绩` between 0 and 100)
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of 选课
-- ----------------------------
INSERT INTO `选课` VALUES ('S2024001', 'C00001', 88.5);
INSERT INTO `选课` VALUES ('S2024001', 'C00002', 92.0);
INSERT INTO `选课` VALUES ('S2024002', 'C00002', 85.0);

SET FOREIGN_KEY_CHECKS = 1;
