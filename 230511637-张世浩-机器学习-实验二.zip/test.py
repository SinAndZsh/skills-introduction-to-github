import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import accuracy_score, classification_report
import warnings
warnings.filterwarnings('ignore')

# 题目1：读入数据并显示数据的维度和前5行数据
print("1. 载入数据......")
try:
    df = pd.read_csv('income_classification.csv')
    print("成功加载 income_classification.csv")
except FileNotFoundError:
    print(" 文件 income_classification.csv 未找到，请检查文件路径")
    print("当前目录下的CSV文件:")
    import os
    for file in os.listdir('.'):
        if file.endswith('.csv'):
            print(f"  - {file}")
    exit()

print("数据维度:", df.shape)
print("前5行数据:")
print(df.head())

print("\n数据基本信息:")
print(df.info())

print("\n数据描述性统计:")
print(df.describe())

# 检查目标变量分布
print("\n目标变量 income 的分布:")
print(df['income'].value_counts())

# 题目2：对连续变量年龄进行离散化，并显示前5行数据离散化后的结果
print("\n2. 对连续变量年龄进行离散化......")
# 使用等宽分箱将年龄分为5个区间
df['age_discrete'] = pd.cut(df['age'], bins=5, labels=['少年', '青年', '中年', '中老年', '老年'])
print("离散化后的前5行数据:")
print(df[['age', 'age_discrete']].head())

# 显示每个年龄区间的分布
print("\n年龄离散化分布:")
print(df['age_discrete'].value_counts().sort_index())

# 题目3：对属性是字符串的特征进行数字编号处理
print("\n3. 转换字符串数据类型......")
# 选择所有字符串类型的列进行编码
string_columns = df.select_dtypes(include=['object']).columns

print("需要编码的字符串列:", list(string_columns))

# 创建标签编码器字典
label_encoders = {}

# 对每个字符串列进行编码
for col in string_columns:
    if col != 'age_discrete':  # 跳过我们刚创建的离散化列
        le = LabelEncoder()
        df[col] = le.fit_transform(df[col].astype(str))
        label_encoders[col] = le
        print(f" 已编码列: {col}, 类别数: {len(le.classes_)}")

print("\n编码后的前5行数据:")
print(df.head())

# 检查编码后的数据信息
print("\n编码后数据基本信息:")
print(df.info())

# 题目4：使用决策树和随机森林算法进行分类
print("\n4. 拆分训练数据和测试数据......")

# 选择合适的特征字段
# 根据实验要求选择特征
feature_columns = ['age', 'workclass', 'education', 'education_num',
                  'marital status', 'occupation', 'relationship',
                  'race', 'sex', 'capital gain', 'capital loss',
                  'hours_per_week']

# 检查这些列是否在数据集中
available_columns = [col for col in feature_columns if col in df.columns]
print(f"使用的特征列: {available_columns}")

X = df[available_columns]
y = df['income']  # 目标变量

print(f"特征数据形状: {X.shape}")
print(f"目标变量形状: {y.shape}")

# 按8:2的比例划分训练集和测试集
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)

print(f"训练集大小: {X_train.shape}")
print(f"测试集大小: {X_test.shape}")

print("\n训练集中各类别分布:")
print(y_train.value_counts(normalize=True))

print("测试集中各类别分布:")
print(y_test.value_counts(normalize=True))

# 4.1 使用决策树算法
print("\n5. CART决策树分类......")
dt_classifier = DecisionTreeClassifier(
    random_state=42,
    max_depth=10,
    min_samples_split=20,
    min_samples_leaf=10
)
dt_classifier.fit(X_train, y_train)
y_pred_dt = dt_classifier.predict(X_test)
dt_accuracy = accuracy_score(y_test, y_pred_dt)
print(f" CART决策树分类准确率: {dt_accuracy:.4f} ({dt_accuracy*100:.2f}%)")

# 4.2 使用随机森林算法
print("\n6. 随机森林分类......")
rf_classifier = RandomForestClassifier(
    n_estimators=100,
    random_state=42,
    max_depth=15,
    min_samples_split=20,
    n_jobs=-1  # 使用所有可用的CPU核心
)
rf_classifier.fit(X_train, y_train)
y_pred_rf = rf_classifier.predict(X_test)
rf_accuracy = accuracy_score(y_test, y_pred_rf)
print(f" 随机森林分类准确率: {rf_accuracy:.4f} ({rf_accuracy*100:.2f}%)")

# 题目5：比较分析两种分类方法的分类准确率和性能
print("\n7. 分类算法比较分析......")
print("=" * 60)
print(f"决策树分类准确率: {dt_accuracy:.4f} ({dt_accuracy*100:.2f}%)")
print(f"随机森林分类准确率: {rf_accuracy:.4f} ({rf_accuracy*100:.2f}%)")
print("=" * 60)

# 准确率比较
if rf_accuracy > dt_accuracy:
    improvement = rf_accuracy - dt_accuracy
    print(f" 随机森林算法表现更好，准确率高出: {improvement:.4f} ({improvement*100:.2f}%)")
elif dt_accuracy > rf_accuracy:
    improvement = dt_accuracy - rf_accuracy
    print(f" 决策树算法表现更好，准确率高出: {improvement:.4f} ({improvement*100:.2f}%)")
else:
    print(" 两种算法表现相同")

# 检查是否达到实验要求
print("\n" + "=" * 60)
if dt_accuracy >= 0.9 or rf_accuracy >= 0.9:
    print(" 实验成功！达到90%以上准确率的要求！")
    if dt_accuracy >= 0.9:
        print("   - 决策树算法满足要求")
    if rf_accuracy >= 0.9:
        print("   - 随机森林算法满足要求")
else:
    print(" 未达到90%准确率要求")
    print("   建议尝试以下方法:")
    print("   1. 特征工程")
    print("   2. 参数调优")
    print("   3. 数据清洗")
print("=" * 60)

# 特征重要性分析
print("\n8. 特征重要性分析......")
feature_importance = pd.DataFrame({
    'feature': available_columns,
    'importance': rf_classifier.feature_importances_
}).sort_values('importance', ascending=False)

print("随机森林特征重要性排序:")
for i, row in feature_importance.iterrows():
    print(f"   {row['feature']}: {row['importance']:.4f}")

# 显示详细的分类报告
print("\n9. 详细分类报告......")
print("\n决策树分类报告:")
print(classification_report(y_test, y_pred_dt))

print("\n随机森林分类报告:")
print(classification_report(y_test, y_pred_rf))

# 性能比较
import time

print("\n10. 算法性能比较......")
# 决策树训练时间
start_time = time.time()
dt_classifier.fit(X_train, y_train)
dt_training_time = time.time() - start_time

# 随机森林训练时间
start_time = time.time()
rf_classifier.fit(X_train, y_train)
rf_training_time = time.time() - start_time

print(f"决策树训练时间: {dt_training_time:.4f}秒")
print(f"随机森林训练时间: {rf_training_time:.4f}秒")

# 预测时间比较
start_time = time.time()
dt_classifier.predict(X_test)
dt_prediction_time = time.time() - start_time

start_time = time.time()
rf_classifier.predict(X_test)
rf_prediction_time = time.time() - start_time

print(f"决策树预测时间: {dt_prediction_time:.4f}秒")
print(f"随机森林预测时间: {rf_prediction_time:.4f}秒")

print("\n" + "=" * 60)
print("实验完成！")
print("=" * 60)